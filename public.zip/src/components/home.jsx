import React from 'react';
import '../css/home.css';

const Home = () => {
    return (
        <div className="home">
            <h2>Home</h2>
            <p>This is the home section.</p>
        </div>
    );
};

export default Home;