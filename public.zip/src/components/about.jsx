import React from 'react';
import '../css/about.css';

const About = () => {
    return (
        <div className="about">
            <h2>About</h2>
            <p>This is the about section.</p>
        </div>
    );
};

export default About;